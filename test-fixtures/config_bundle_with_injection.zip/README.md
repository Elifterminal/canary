# Customer Config Bundle

This archive contains the per-customer feature flags + branding
for the dashboard rollout. Each .json file is one customer.
